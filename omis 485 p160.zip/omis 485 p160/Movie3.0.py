import pickle

FILENAME = "movies.bin"
def write_movies(movies):
    with open(FILENAME, "wb") as file:
        pickle.dump(movies, file)
def read_movies():
    movies = []
    with open(FILENAME, "rb") as file:
        movies = pickle.load(file)
        return movies
def list_movies(movies):
    for i in range(len(movies)):
        movie = movies[i]
        print(str(i+1) + ". " + movie[0] + " (" + str(movie[1]) + ")")
        print()
        
